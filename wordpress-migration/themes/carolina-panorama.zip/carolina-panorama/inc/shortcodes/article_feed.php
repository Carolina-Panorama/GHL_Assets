<?php
/**
 * Shortcode: cp_article_feed
 * Widget: Article Feed
 */

function cp_shortcode_article_feed( $atts = [], $content = null, $tag = '' ) {
    // Enqueue dependencies
    wp_enqueue_script( 'cp-global-js' );
    wp_enqueue_style( 'cp-article-card-styles' );

    // Shortcode attributes with defaults
    $atts = shortcode_atts( [ 'category' => '', 'per_page' => 10, 'page' => 1 ], $atts, 'cp_article_feed' );

    ob_start();
    ?>
<!-- Article Feed Widget with Pagination and Filtering -->
<!-- Include shared-article-card-styles.css in your page -->

<style>
    .article-list-feed-wrapper {
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        padding: clamp(12px, 1.6vw, 20px);
    }
    .article-list-container {
        display: flex;
        flex-direction: column;
        gap: 0;
    }
    .article-list-item {
        display: block;
    }
    .article-list-item .cp-article-card {
        display: grid;
        grid-template-columns: 1fr 280px;
        gap: clamp(20px, 2.5vw, 32px);
        align-items: center;
        padding: clamp(16px, 2vw, 24px) clamp(8px, 1vw, 10px);
    }
    .article-list-item .cp-article-card-link {
        display: contents;
    }
    .article-list-item .cp-article-content {
        padding: 0;
        gap: clamp(6px, 0.8vw, 8px);
        order: 1;
    }
    .article-list-item .cp-article-image {
        height: 180px;
        border-radius: 6px;
        order: 2;
    }
    .article-list-item .cp-article-title {
        font-size: clamp(1.125rem, 2vw, 1.375rem);
        line-height: 1.25;
        margin-bottom: clamp(6px, 0.8vw, 8px);
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        font-weight: 600;
    }
    .article-list-item .cp-article-meta {
        margin: 0;
        font-size: clamp(0.8rem, 1vw, 0.875rem);
    }
    .article-list-item .cp-article-description {
        font-size: clamp(0.875rem, 1.1vw, 0.9375rem);
        line-height: 1.5;
        margin: clamp(8px, 1vw, 10px) 0;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    .article-list-item .cp-article-tags {
        margin-top: clamp(8px, 1vw, 10px);
    }
    .article-list-item .cp-article-read-more {
        margin-top: clamp(8px, 1vw, 10px);
        font-size: clamp(0.875rem, 1vw, 0.9375rem);
    }
    .article-list-item:not(:last-child) {
        border-bottom: 1px solid #e5e7eb;
    }
    @media (max-width: 768px) {
        .article-list-item .cp-article-card {
            grid-template-columns: 1fr;
            gap: 12px;
        }
        .article-list-item .cp-article-content {
            order: 2;
        }
        .article-list-item .cp-article-image {
            order: 1;
            height: 200px;
        }
        .article-list-item .cp-article-title {
            font-size: 1.125rem;
        }
        .article-list-item .cp-article-description {
            -webkit-line-clamp: 2;
        }
    }
    .article-feed-pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 12px;
        margin: 24px 0 0 0;
        min-height: 48px;
    }

    .article-feed-pagination .page-count {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
        min-width: 60px;
        text-align: center;
        height: 40px;
    }
    
    .article-feed-pagination button {
        width: 48px;
        height: 40px;
        border: none;
        background: #3b82f6;
        color: #fff;
        border-radius: 6px;
        cursor: pointer;
        font-size: 1.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s;
    }
    .article-feed-pagination button:disabled {
        background: #e5e7eb;
        color: #9ca3af;
        cursor: not-allowed;
    }

    /* Header container styles for all four states */
    #category-header-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 16px auto 24px auto;
        max-width: 800px;
    }
    
    #category-header-container #category-title {
        margin: 0;
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    
    /* Label above the title (for tag and author) */
    #category-header-container .header-label {
        font-size: 0.875rem;
        font-weight: 500;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-bottom: 6px;
        opacity: 0.9;
        display: block;
    }
    
    /* Main title styling */
    #category-header-container .header-title {
        font-size: 2.2rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1px;
        font-family: 'Georgia', serif;
        line-height: 1.2;
        display: block;
    }
    
    /* Tag and Author states - Carolina Navy Blue background with gradient */
    #category-header-container.tag-header,
    #category-header-container.author-header {
        background: linear-gradient(to bottom, #0055aa, #003366);
        color: #fff;
        border-radius: 12px;
        padding: 20px 40px;
    }
    
    /* Category state - uses existing cp-article-tag colors with gradient */
    #category-header-container.cp-article-tag {
        color: #fff;
        border-radius: 12px;
        padding: 20px 40px;
        position: relative;
        overflow: hidden;
    }
    
    #category-header-container.cp-article-tag::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(to bottom, rgba(255,255,255,0.15), rgba(0,0,0,0.2));
        pointer-events: none;
    }
    
    /* Latest/All state - keep original styling */
    #category-header-container.latest-header #category-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1a202c;
        margin: 0;
        padding-bottom: 20px;
        border-bottom: 3px solid #2563eb;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        font-family: 'Georgia', serif;
    }
</style>

<div class="article-list-feed-wrapper">
    <div id="category-header-container">
        <h1 id="category-title"></h1>
    </div>
    <div class="article-list-container" id="article-feed-container">
        <!-- Articles will be rendered here -->
    </div>
    <div class="article-feed-pagination" id="article-feed-pagination">
        <!-- Pagination buttons will be rendered here -->
    </div>
</div>

<script>
// Wait for CarolinaPanorama global before running widget logic
function waitForCarolinaPanorama(callback, timeout = 5000) {
    const start = Date.now();
    (function check() {
        if (window.CarolinaPanorama) {
            callback();
        } else if (Date.now() - start < timeout) {
            setTimeout(check, 30);
        } else {
            console.error('CarolinaPanorama global not found.');
        }
    })();
}

waitForCarolinaPanorama(function() {
    const container = document.getElementById('article-feed-container');
    const pagination = document.getElementById('article-feed-pagination');
    const categoryLabelDiv = document.getElementById('category-title');
    const ARTICLES_PER_PAGE = 10;
    let currentPage = 1;
    let totalCount = 0;
    let currentFilter = {};

    const apiBase = window.CarolinaPanorama.API_BASE_URL || 'https://cms.carolinapanorama.org';

    // Simple slug helper to match names coming from API
    function slugify(str) {
        return String(str || '')
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-');
    }

    let categoriesCache = null;
    let authorsCache = null;

    async function ensureCategories() {
        if (categoriesCache) return categoriesCache;
        try {
            const res = await fetch(`${apiBase}/api/public/categories`);
            const json = await res.json();
            if (json.success && Array.isArray(json.data)) {
                categoriesCache = json.data;
            } else {
                categoriesCache = [];
            }
        } catch (e) {
            console.error('Failed to load categories from CMS:', e);
            categoriesCache = [];
        }
        return categoriesCache;
    }

    async function ensureAuthors() {
        if (authorsCache) return authorsCache;
        try {
            const res = await fetch(`${apiBase}/api/public/authors`);
            const json = await res.json();
            if (json.success && Array.isArray(json.data)) {
                authorsCache = json.data;
            } else {
                authorsCache = [];
            }
        } catch (e) {
            console.error('Failed to load authors from CMS:', e);
            authorsCache = [];
        }
        return authorsCache;
    }

    // Utility to get filter from URL (category or tag) or query parameters
    function getFilterFromUrl() {
        const path = window.location.pathname;
        const queryParams = new URLSearchParams(window.location.search);
        
        // Check URL path first (for old-style URLs like /category/name)
        const matchCategory = path.match(/\/category\/([^\/]+)/);
        const matchTag = path.match(/\/tag\/([^\/]+)/);
        const matchAuthor = path.match(/\/author\/([^\/]+)/);
        
        if (matchCategory) {
            return { categoryUrlSlug: decodeURIComponent(matchCategory[1].replace(/\+/g, ' ')) };
        } else if (matchTag) {
            return { tag: decodeURIComponent(matchTag[1].replace(/\+/g, ' ')) };
        } else if (matchAuthor) {
            return { author: decodeURIComponent(matchAuthor[1].replace(/\+/g, ' ')) };
        }
        
        // Check query parameters (from redirects: ?category=name, ?tag=name, ?author=name)
        if (queryParams.has('category')) {
            return { categoryQueryParam: queryParams.get('category') };
        } else if (queryParams.has('tag')) {
            return { tag: queryParams.get('tag') };
        } else if (queryParams.has('author')) {
            return { author: queryParams.get('author') };
        }
        
        return {};
    }

    // Fetch articles for current page and filter from CMS public API
    async function fetchArticles(page = 1) {
        currentFilter = getFilterFromUrl();
        const params = new URLSearchParams();
        params.set('page', String(page));
        params.set('per_page', String(ARTICLES_PER_PAGE));

        let categoryDetails = null;
        let authorDetails = null;

        // Handle category from URL path
        if (currentFilter.categoryUrlSlug) {
            const slug = currentFilter.categoryUrlSlug;
            const cats = await ensureCategories();
            const match = cats.find(c => slugify(c.name) === slug);
            if (match) {
                params.set('category', match.name);
                categoryDetails = { 
                    label: match.name,
                    description: match.description || ''
                };
            }
        }
        
        // Handle category from query parameter (from redirects)
        if (currentFilter.categoryQueryParam) {
            const categoryName = currentFilter.categoryQueryParam;
            params.set('category', categoryName);
            categoryDetails = { 
                label: categoryName,
                description: ''
            };
        }

        // Handle tag from URL or query parameter
        if (currentFilter.tag) {
            const tagName = currentFilter.tag.replace(/-/g, ' ');
            params.set('tag', tagName);
        }

        // Handle author from URL path
        if (currentFilter.author && !currentFilter.categoryQueryParam && !currentFilter.categoryUrlSlug) {
            const slug = currentFilter.author;
            const authors = await ensureAuthors();
            const match = authors.find(a => slugify(a.name) === slug);
            if (match) {
                params.set('author_id', String(match.id));
                authorDetails = { 
                    name: match.name,
                    bio: match.bio || ''
                };
            }
        }

        const url = `${apiBase}/api/public/articles?${params.toString()}`;
        const response = await fetch(url);
        const data = await response.json();
        if (!data.success || !Array.isArray(data.data)) {
            totalCount = 0;
            return { articles: [], categoryDetails, authorDetails };
        }
        const paginationInfo = data.pagination || {};
        totalCount = paginationInfo.total || data.data.length || 0;

        return {
            articles: data.data.map(article => ({
                url: article.slug ? `/article#${encodeURIComponent(article.slug)}` : '',
                title: article.title,
                description: article.excerpt || '',
                image: article.featured_image || "https://storage.googleapis.com/msgsndr/9Iv8kFcMiUgScXzMPv23/media/697bd8644d56831c95c3248d.svg",
                author: article.author && article.author.name ? article.author.name : 'Carolina Panorama',
                date: article.publish_date,
                categories: Array.isArray(article.categories) && article.categories.length > 0
                    ? article.categories.map(cat => cat.name)
                    : ['News']
            })),
            categoryDetails,
            authorDetails
        };
    }

    // Render articles
    async function renderArticles(articles) {
        if (!articles || articles.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #666;">No articles found.</p>';
            return;
        }
        const cardsHTML = await Promise.all(articles.map((data, index) => createArticleCard(data, index)));
        container.innerHTML = cardsHTML.join('');
    }

    // Render pagination
    function renderPagination(page, total) {
        const prevDisabled = page === 1;
        const nextDisabled = total <= page * ARTICLES_PER_PAGE;
        const totalPages = Math.max(1, Math.ceil(total / ARTICLES_PER_PAGE));
        pagination.innerHTML = `
            <button id="feed-prev" ${prevDisabled ? 'disabled' : ''} aria-label="Previous Page">&laquo;</button>
            <span class="page-count">${page} / ${totalPages}</span>
            <button id="feed-next" ${nextDisabled ? 'disabled' : ''} aria-label="Next Page">&raquo;</button>
        `;
        
        // Debounce pagination clicks to prevent double-clicks
        const debouncedChangePage = window.CarolinaPanorama.debounce(changePage, 300);
        
        document.getElementById('feed-prev').onclick = function() {
            if (!prevDisabled) debouncedChangePage(page - 1);
        };
        document.getElementById('feed-next').onclick = function() {
            if (!nextDisabled) debouncedChangePage(page + 1);
        };
    }

    // Create article card HTML
    async function createArticleCard(data, index) {
        // Get category styles dynamically
        const categoryTagsHTML = await Promise.all(
            data.categories.slice(0, 2).map(async cat => {
                const categoryClass = cat.toLowerCase().replace(/\s+/g, '-');
                const style = await window.CarolinaPanorama.getCategoryStyle(cat);
                return `<span class="cp-article-tag ${categoryClass}" style="${style}">${cat}</span>`;
            })
        );
        
        const imageUrl = data.image || 'https://storage.googleapis.com/msgsndr/9Iv8kFcMiUgScXzMPv23/media/697bd8644d56831c95c3248d.svg';
        // Lazy load images after the first 3 articles
        const loadingAttr = index >= 3 ? 'loading="lazy"' : 'loading="eager"';
        
        return `
            <div class="article-list-item">
                <article class="cp-article-card">
                    <a href="${data.url}" class="cp-article-card-link">
                        <img src="${imageUrl}" alt="${data.title}" class="cp-article-image" ${loadingAttr}>
                        <div class="cp-article-content">
                            <h2 class="cp-article-title">${data.title}</h2>
                            <div class="cp-article-meta">
                                <span class="cp-article-author">${data.author}</span>
                                <span class="cp-article-date">${formatDate(data.date)}</span>
                            </div>
                            <p class="cp-article-description">${data.description}</p>
                            <div class="cp-article-tags">
                                ${categoryTagsHTML.join('')}
                            </div>
                            <span class="cp-article-read-more">Read More</span>
                        </div>
                    </a>
                </article>
            </div>
        `;
    }

    function formatDate(date) {
        const options = { month: 'numeric', day: 'numeric', year: 'numeric' };
        return 'Published on: ' + new Date(date).toLocaleDateString('en-US', options);
    }

    // Change page
    async function changePage(page) {
        currentPage = page;
        const { articles, categoryDetails, authorDetails } = await fetchArticles(page);
        await renderArticles(articles);
        renderPagination(page, totalCount);
        
        // Update header with stylized states
        const headerContainer = document.getElementById('category-header-container');
        const headerTitle = document.getElementById('category-title');
        const filter = getFilterFromUrl();
        
        // Reset classes and inline styles
        headerContainer.className = '';
        headerContainer.removeAttribute('style');
        
        // SEO Meta injection based on page type
        if (categoryDetails && categoryDetails.label) {
            // Category state - use API color_code for background
            const categoryClass = categoryDetails.label.toLowerCase().replace(/\s+/g, '-');
            headerContainer.className = 'cp-article-tag ' + categoryClass;
            
            // Apply API color_code as inline style for header background
            const categoryStyle = await window.CarolinaPanorama.getCategoryStyle(categoryDetails.label);
            if (categoryStyle) {
                headerContainer.setAttribute('style', categoryStyle);
            }
            
            headerTitle.innerHTML = `<span class="header-title">${categoryDetails.label}</span>`;
            
            // Set SEO meta for category pages with description and extracted keywords
            const categoryName = categoryDetails.label;
            const description = categoryDetails.description || `Browse the latest ${categoryName} articles from Carolina Panorama`;
            
            // Build contextual keywords
            const baseKeywords = [categoryName];
            
            // Add Black-focused variations for relevant categories
            const blackFocusedCategories = ['Business', 'Finance', 'Politics', 'Health', 'Education', 'Culture', 'Community'];
            if (blackFocusedCategories.includes(categoryName)) {
                baseKeywords.push(`Black ${categoryName}`);
                baseKeywords.push(`African American ${categoryName}`);
            }
            
            // Add geographic variations
            const geoVariations = ['South Carolina', 'Columbia', 'Orangeburg', 'Lexington'];
            geoVariations.forEach(location => {
                baseKeywords.push(`${location} ${categoryName}`);
            });
            
            // Extract keywords from description if available
            if (categoryDetails.description && window.CarolinaPanorama.extractKeywords) {
                const extractedKeywords = window.CarolinaPanorama.extractKeywords(categoryDetails.description, 3);
                if (extractedKeywords) {
                    baseKeywords.push(extractedKeywords);
                }
            }
            
            // Add standard context
            baseKeywords.push('Carolina Panorama', 'news', 'articles');
            
            const keywords = baseKeywords.join(', ');
            
            window.CarolinaPanorama.setPageMeta({
                title: `${categoryName} Articles | Carolina Panorama`,
                description: description,
                keywords: keywords,
                url: window.location.href,
                type: 'website'
            });
        } else if (filter.tag) {
            // Tag state - Carolina Navy Blue box with label
            headerContainer.className = 'tag-header';
            headerTitle.innerHTML = `<span class="header-label">Tagged Entity</span><span class="header-title">${filter.tag}</span>`;
            
            // Set SEO meta for tag pages
            window.CarolinaPanorama.setPageMeta({
                title: `Articles tagged: ${filter.tag} | Carolina Panorama`,
                description: `Explore articles about ${filter.tag} from Carolina Panorama`,
                keywords: `${filter.tag}, Carolina Panorama, tags, topics`,
                url: window.location.href,
                type: 'website'
            });
        } else if (filter.author) {
            // Author state - Carolina Navy Blue box with label
            let authorName = 'Unknown Author';
            let authorBio = '';
            if (authorDetails && authorDetails.name) {
                authorName = authorDetails.name;
                authorBio = authorDetails.bio || '';
            }
            headerContainer.className = 'author-header';
            headerTitle.innerHTML = `<span class="header-label">Written by:</span><span class="header-title">${authorName}</span>`;
            
            // Set SEO meta for author pages
            window.CarolinaPanorama.setPageMeta({
                title: `Articles by ${authorName} | Carolina Panorama`,
                description: authorBio || `Read articles written by ${authorName} at Carolina Panorama`,
                keywords: `${authorName}, author, Carolina Panorama, articles`,
                url: window.location.href,
                type: 'profile'
            });
        } else {
            // Latest Articles - keep original style
            headerContainer.className = 'latest-header';
            headerTitle.textContent = 'Latest Articles';
            
            // Set SEO meta for homepage/latest
            window.CarolinaPanorama.setPageMeta({
                title: 'Latest Articles | Carolina Panorama',
                description: 'Browse the latest news and articles from Carolina Panorama',
                keywords: 'Carolina Panorama, latest news, articles, updates',
                url: window.location.href,
                type: 'website'
            });
        }
        
        headerContainer.style.display = '';
    }

    // Initial load
    changePage(1);
});
</script>
    <?php
    return ob_get_clean();
}

// Register shortcode
add_shortcode( 'cp_article_feed', 'cp_shortcode_article_feed' );
