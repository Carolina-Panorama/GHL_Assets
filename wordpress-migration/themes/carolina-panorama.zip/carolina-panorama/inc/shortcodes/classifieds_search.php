<?php
/**
 * Shortcode: cp_classifieds_search
 * Widget: Classifieds Search
 */

function cp_shortcode_classifieds_search( $atts = [], $content = null, $tag = '' ) {
    // Enqueue dependencies
    wp_enqueue_script( 'cp-global-js' );

    ob_start();
    ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/instantsearch.css@7.4.5/themes/satellite-min.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
    .classifieds-search-widget {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        min-height: 100vh;
        padding: 0px;
        margin: 0;
        box-sizing: border-box;
    }

    .classifieds-search-widget *,
    .classifieds-search-widget *::before,
    .classifieds-search-widget *::after {
        box-sizing: border-box;
    }

    .classifieds-search-widget .search-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0px 20px;
    }

    .classifieds-search-widget .search-header {
        text-align: center;
        margin-bottom: 24px;
        color: white;
    }

    .classifieds-search-widget .search-header h1 {
        font-size: 3.5rem;
        font-weight: 700;
        margin: 0 0 16px 0;
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        letter-spacing: -0.02em;
    }

    .classifieds-search-widget .search-header p {
        font-size: 1.25rem;
        color: #000;
        margin: 0;
        font-weight: 400;
    }

    .classifieds-search-widget .search-box {
        margin-bottom: 32px;
        width: 100%;
    }

    .classifieds-search-widget .search-filters {
        display: grid;
        grid-template-columns: 320px 1fr;
        gap: 40px;
        align-items: stretch;
    }

    .classifieds-search-widget .search-sidebar {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 32px;
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        position: sticky;
        top: 20px;
        height: fit-content;
    }

    .classifieds-search-widget .search-results {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 32px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        min-height: 100%;
        display: flex;
        flex-direction: column;
    }

    .classifieds-search-widget .ais-SearchBox {
        position: relative;
    }

    .classifieds-search-widget .ais-SearchBox-input {
        width: 100%;
        padding: 20px 24px 20px 56px;
        font-size: 18px;
        font-weight: 500;
        border: 2px solid rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        color: #1f2937;
    }

    .classifieds-search-widget .ais-SearchBox-input:focus {
        outline: none;
        border-color: #003366;
        box-shadow: 0 0 0 4px rgba(0, 51, 102, 0.1), 0 12px 40px rgba(0, 0, 0, 0.3);
        background: rgba(255, 255, 255, 1);
        transform: translateY(-2px);
    }

    .classifieds-search-widget .ais-SearchBox-input::placeholder {
        color: #9ca3af;
        font-weight: 400;
    }

    .classifieds-search-widget .ais-SearchBox-submit,
    .classifieds-search-widget .ais-SearchBox-reset {
        padding: 12px;
        border: none;
        background: transparent;
        cursor: pointer;
        border-radius: 8px;
        transition: background-color 0.2s;
    }

    .classifieds-search-widget .ais-SearchBox-submit:hover,
    .classifieds-search-widget .ais-SearchBox-reset:hover {
        background: rgba(0, 51, 102, 0.1);
    }

    .classifieds-search-widget .ais-SearchBox-submitIcon,
    .classifieds-search-widget .ais-SearchBox-resetIcon {
        width: 20px;
        height: 20px;
        fill: #003366;
    }

    /* Sidebar styling */
    .classifieds-search-widget .search-sidebar h3 {
        font-size: 1.1rem;
        font-weight: 600;
        color: #1f2937;
        margin: 0 0 16px 0;
        padding-bottom: 8px;
        border-bottom: 2px solid #f3f4f6;
    }

    .classifieds-search-widget .search-sidebar h3:not(:first-child) {
        margin-top: 32px;
    }

    .classifieds-search-widget .ais-RefinementList-item {
        padding: 10px 0;
        border-bottom: 1px solid #f3f4f6;
    }

    .classifieds-search-widget .ais-RefinementList-item:last-child {
        border-bottom: none;
    }

    .classifieds-search-widget .ais-RefinementList-label {
        display: flex;
        align-items: center;
        cursor: pointer;
        font-weight: 500;
        color: #374151;
        transition: color 0.2s;
    }

    .classifieds-search-widget .ais-RefinementList-label:hover {
        color: #003366;
    }

    .classifieds-search-widget .ais-RefinementList-checkbox {
        width: 18px;
        height: 18px;
        margin-right: 12px;
        accent-color: #003366;
    }

    .classifieds-search-widget .ais-RefinementList-count {
        margin-left: auto;
        background: linear-gradient(135deg, #003366, #aaa);
        color: white;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        min-width: 24px;
        text-align: center;
    }

    .classifieds-search-widget .ais-Stats {
        margin-bottom: 24px;
        padding: 16px 0;
        border-bottom: 2px solid #f3f4f6;
    }

    .classifieds-search-widget .ais-Stats-text {
        font-size: 0.95rem;
        color: #6b7280;
        font-weight: 500;
    }

    .search-result-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 28px;
        margin-bottom: 24px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        gap: 24px;
        min-height: 220px;
        width: 100%;
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
    }

    .search-result-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #003366 0%, #aaa 100%);
        opacity: 0;
        transition: opacity 0.3s;
    }

    .search-result-card:hover {
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
        transform: translateY(-4px);
        border-color: #003366;
    }

    .search-result-card:hover::before {
        opacity: 1;
    }

    /* Paid listing styling */
    .search-result-card.paid-listing {
        border: 2px solid #fbbf24;
        background: linear-gradient(135deg, #fffbeb 0%, #ffffff 100%);
        box-shadow: 0 8px 32px rgba(251, 191, 36, 0.15);
    }

    .search-result-card.paid-listing::before {
        background: linear-gradient(90deg, #fbbf24 0%, #f59e0b 100%);
        opacity: 1;
        height: 6px;
    }

    .paid-badge {
        position: absolute;
        top: 16px;
        right: 16px;
        background: linear-gradient(135deg, #fbbf24, #f59e0b);
        color: white;
        padding: 8px 16px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        box-shadow: 0 4px 12px rgba(251, 191, 36, 0.3);
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }

    .search-result-image {
        flex-shrink: 0;
        width: 240px;
        height: 180px;
        border-radius: 12px;
        overflow: hidden;
        background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
        position: relative;
    }

    .search-result-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s;
    }

    .search-result-card:hover .search-result-image img {
        transform: scale(1.05);
    }

    .search-result-content {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .search-result-image {
        flex-shrink: 0;
        width: 200px;
        height: 150px;
        border-radius: 6px;
        overflow: hidden;
        background: #f7fafc;
    }

    .search-result-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .search-result-content {
        flex: 1;
        min-width: 0;
    }

    .ais-SearchBox {
        position: relative;
    }

    .ais-SearchBox-submit,
    .ais-SearchBox-reset {
        padding: 8px;
    }

    .ais-SearchBox-submitIcon,
    .ais-SearchBox-resetIcon {
        width: 16px;
        height: 16px;
    }

    .search-result-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin: 0 0 12px 0;
        color: #111827;
        line-height: 1.3;
        letter-spacing: -0.01em;
    }

    .search-result-title a {
        color: inherit;
        text-decoration: none;
        transition: color 0.2s;
    }

    .search-result-title a:hover {
        color: #003366;
    }

    .search-result-meta {
        font-size: 0.9rem;
        color: #6b7280;
        margin-bottom: 16px;
        font-weight: 500;
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
    }

    .search-result-meta span {
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }

    .search-result-price {
        font-size: 1.5rem;
        font-weight: 800;
        margin-bottom: 12px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .search-result-price.free {
        color: #059669;
        background: #d1fae5;
        padding: 8px 16px;
        border-radius: 24px;
        font-size: 1.1rem;
    }

    .search-result-price.negotiable {
        color: #d97706;
    }

    .search-result-price:not(.free):not(.negotiable) {
        color: #1f2937;
    }

    .search-result-excerpt {
        color: #4b5563;
        line-height: 1.6;
        margin-bottom: 16px;
        font-size: 1rem;
        flex-grow: 1;
    }

    .search-result-location {
        font-size: 0.9rem;
        color: #6b7280;
        display: flex;
        align-items: center;
        gap: 6px;
        margin-bottom: 8px;
        font-weight: 500;
    }

    .search-result-contact {
        font-size: 0.9rem;
        color: #003366;
        font-weight: 500;
    }

    .search-result-title a {
        color: inherit;
        text-decoration: none;
    }

    .search-result-title a:hover {
        color: #4299e1;
    }

    .search-result-meta {
        font-size: 0.875rem;
        color: #718096;
        margin-bottom: 12px;
    }

    .search-result-price {
        font-size: 1.25rem;
        font-weight: 700;
        color: #2b6cb0;
        margin-bottom: 8px;
    }

    .search-result-price.free {
        color: #38a169;
    }

    .search-result-price.negotiable {
        color: #d69e2e;
    }

    .search-result-excerpt {
        color: #4a5568;
        line-height: 1.6;
        margin-bottom: 12px;
    }

    .search-result-location {
        font-size: 0.875rem;
        color: #718096;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .search-result-contact {
        font-size: 0.875rem;
        color: #4299e1;
        margin-top: 8px;
    }

    .condition-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        margin-left: 12px;
        letter-spacing: 0.5px;
    }

    .condition-new { 
        background: linear-gradient(135deg, #d1fae5, #a7f3d0); 
        color: #065f46; 
    }
    .condition-like-new { 
        background: linear-gradient(135deg, #dbeafe, #bfdbfe); 
        color: #1e40af; 
    }
    .condition-good { 
        background: linear-gradient(135deg, #fed7d7, #fbb6ce); 
        color: #991b1b; 
    }
    .condition-fair { 
        background: linear-gradient(135deg, #fef3c7, #fde68a); 
        color: #92400e; 
    }
    .condition-poor { 
        background: linear-gradient(135deg, #f3f4f6, #e5e7eb); 
        color: #374151; 
    }

    mark {
        background: linear-gradient(135deg, #fef08a, #fde047);
        padding: 4px 6px;
        border-radius: 6px;
        font-weight: 500;
    }

    /* Price range and form elements */
    .ais-RangeInput {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 20px;
    }

    .ais-RangeInput-input {
        flex: 1;
        padding: 12px;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        transition: border-color 0.2s;
    }

    .ais-RangeInput-input:focus {
        outline: none;
        border-color: #003366;
    }

    .ais-RangeInput-separator {
        color: #6b7280;
        font-weight: 500;
    }

    .ais-RangeInput-submit {
        background: linear-gradient(135deg, #003366, #aaa);
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.2s;
    }

    .ais-RangeInput-submit:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 51, 102, 0.3);
    }

    /* Custom multi-select dropdown styles */
    .custom-dropdown {
        position: relative;
        margin-bottom: 15px;
    }

    .custom-dropdown-input {
        width: 100%;
        padding: 10px;
        border: 1px solid #e2e8f0;
        border-radius: 4px;
        cursor: pointer;
        background: white;
        font-size: 14px;
    }

    .custom-dropdown-input:focus {
        outline: none;
        border-color: #4299e1;
    }

    .custom-dropdown-list {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 4px;
        margin-top: 4px;
        max-height: 300px;
        overflow-y: auto;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        display: none;
    }

    .custom-dropdown-list.active {
        display: block;
    }

    .custom-dropdown-item {
        padding: 8px 12px;
        cursor: pointer;
        display: flex;
        align-items: center;
        transition: background 0.2s;
    }

    .custom-dropdown-item:hover {
        background: #f7fafc;
    }

    .custom-dropdown-item input[type="checkbox"] {
        margin-right: 8px;
    }

    .custom-dropdown-item label {
        cursor: pointer;
        flex: 1;
        display: flex;
        justify-content: space-between;
    }

    .custom-dropdown-count {
        color: #718096;
        font-size: 12px;
    }

    /* Pagination styling */
    .ais-Pagination {
        margin-top: 40px;
        display: flex;
        justify-content: center;
    }

    .ais-Pagination-list {
        display: flex;
        gap: 8px;
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .ais-Pagination-item {
        display: flex;
    }

    .ais-Pagination-link {
        padding: 12px 16px;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        text-decoration: none;
        color: #374151;
        font-weight: 500;
        transition: all 0.2s;
        background: white;
    }

    .ais-Pagination-link:hover {
        border-color: #003366;
        color: #003366;
        transform: translateY(-1px);
    }

    .ais-Pagination-item--selected .ais-Pagination-link {
        background: linear-gradient(135deg, #003366, #aaa);
        color: white;
        border-color: #003366;
    }

    .ais-Pagination-item--disabled .ais-Pagination-link {
        opacity: 0.5;
        cursor: not-allowed;
    }

    @media (max-width: 1024px) {
        .classifieds-search-widget .search-filters {
            grid-template-columns: 280px 1fr;
            gap: 24px;
        }
    }

    @media (max-width: 768px) {
        .classifieds-search-widget {
            padding: 20px 0;
        }

        .classifieds-search-widget .search-container {
            padding: 0px 16px;
        }

        .classifieds-search-widget .search-header h1 {
            font-size: 2.5rem;
        }

        .classifieds-search-widget .search-header p {
            font-size: 1.1rem;
            margin-bottom: 20px;
        }

        .classifieds-search-widget .search-box {
            margin-bottom: 20px;
        }

        .classifieds-search-widget .search-filters {
            grid-template-columns: 1fr;
            gap: 20px;
        }
        
        .classifieds-search-widget .search-sidebar {
            order: 2;
            position: static;
            padding: 20px;
            border-radius: 16px;
        }

        .classifieds-search-widget .search-results {
            padding: 20px;
            border-radius: 16px;
        }

        .classifieds-search-widget .search-result-card {
            flex-direction: column;
            padding: 20px;
            min-height: auto;
            border-radius: 16px;
            margin-bottom: 16px;
        }

        .classifieds-search-widget .search-result-image {
            width: 100%;
            height: 200px;
            border-radius: 12px;
        }

        .classifieds-search-widget .ais-SearchBox-input {
            font-size: 16px; /* Prevents zoom on iOS */
            padding: 18px 24px 18px 52px;
            border-radius: 12px;
        }

        .classifieds-search-widget .search-result-title {
            font-size: 1.4rem;
            line-height: 1.3;
        }

        .classifieds-search-widget .search-result-description {
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .classifieds-search-widget .paid-badge {
            top: 12px;
            right: 12px;
            padding: 8px 12px;
            font-size: 0.75rem;
        }

        /* Better touch targets for filter items */
        .classifieds-search-widget .ais-RefinementList-item,
        .classifieds-search-widget .ais-Menu-item {
            padding: 12px 0;
        }

        .classifieds-search-widget .ais-RefinementList-labelText,
        .classifieds-search-widget .ais-Menu-link {
            font-size: 1rem;
            line-height: 1.4;
        }
    }

    @media (max-width: 480px) {
        .classifieds-search-widget {
            padding: 16px 0;
        }

        .classifieds-search-widget .search-container {
            padding: 0px 12px;
        }

        .classifieds-search-widget .search-header h1 {
            font-size: 1.75rem;
            line-height: 1.2;
        }

        .classifieds-search-widget .search-header p {
            font-size: 1rem;
            margin-bottom: 16px;
        }

        .classifieds-search-widget .search-box {
            margin-bottom: 16px;
        }

        .classifieds-search-widget .search-filters {
            gap: 16px;
        }

        .classifieds-search-widget .search-sidebar {
            padding: 16px;
            border-radius: 12px;
        }

        .classifieds-search-widget .search-results {
            padding: 16px;
            border-radius: 12px;
        }

        .classifieds-search-widget .search-result-card {
            margin-bottom: 12px;
            padding: 16px;
        }

        .classifieds-search-widget .search-result-title {
            font-size: 1.2rem;
            line-height: 1.3;
        }

        .classifieds-search-widget .search-result-description {
            font-size: 0.9rem;
        }

        .classifieds-search-widget .ais-SearchBox-input {
            padding: 16px 20px 16px 48px;
        }

        .classifieds-search-widget .ais-Pagination-link {
            padding: 12px 14px;
            min-height: 44px; /* Apple's minimum touch target */
            min-width: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Improve filter section spacing */
        .classifieds-search-widget .search-sidebar h3 {
            font-size: 1rem;
            margin-bottom: 12px;
        }

        .classifieds-search-widget .ais-RefinementList-item,
        .classifieds-search-widget .ais-Menu-item {
            padding: 10px 0;
        }
    }
</style>

<div class="classifieds-search-widget">
<div class="search-container">
    <div class="search-header">
        <p>Find what you're looking for in our local classified ads</p>
    </div>

    <div id="searchbox" class="search-box"></div>

    <div class="search-filters">
        <aside class="search-sidebar">
            <h3>Filter by Category</h3>
            <div id="category-filter"></div>
        </aside>

        <div class="search-results">
            <div id="stats"></div>
            <div id="hits"></div>
            <div id="pagination"></div>
        </div>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/algoliasearch@4.14.2/dist/algoliasearch-lite.umd.js"></script>
<script src="https://cdn.jsdelivr.net/npm/instantsearch.js@4.49.1/dist/instantsearch.production.min.js"></script>

<script>
(function() {
    'use strict';
    
    // Wait for both DOM and scripts to load
    function initializeSearch() {
        if (typeof algoliasearch === 'undefined' || typeof instantsearch === 'undefined') {
            console.log('Waiting for Algolia libraries to load...');
            setTimeout(initializeSearch, 100);
            return;
        }
        
        console.log('Initializing classifieds search...');
        
        // Use public Algolia Index and Search API Key - update with your classifieds index
        const searchClient = algoliasearch('L5HJO2NLX1', '303488aa839f0fc1c6c0467ae84a0354');

    // Check URL for query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const queryParam = urlParams.get('q') || urlParams.get('query') || '';

    const search = instantsearch({
        indexName: 'prod_CarolinaPanorama_Classifieds', // Update with your classifieds index name
        searchClient,
        routing: true,
        initialUiState: {
            prod_CarolinaPanorama_Classifieds: {
                query: queryParam,
            },
        },
    });

    // Search box
    search.addWidgets([
        instantsearch.widgets.searchBox({
            container: '#searchbox',
            placeholder: 'Search classifieds...',
            showSubmit: false,
            showReset: true,
        })
    ]);

    // Stats
    search.addWidgets([
        instantsearch.widgets.stats({
            container: '#stats',
            templates: {
                text(data, { html }) {
                    let resultText = '';
                    if (data.nbHits === 0) {
                        resultText = 'No results';
                    } else if (data.nbHits === 1) {
                        resultText = '1 result';
                    } else {
                        resultText = `${data.nbHits.toLocaleString()} results`;
                    }
                    return html`<span>${resultText} found in ${data.processingTimeMS}ms</span>`;
                }
            }
        })
    ]);

    // Category filter
    search.addWidgets([
        instantsearch.widgets.refinementList({
            container: '#category-filter',
            attribute: 'category',
            limit: 10,
            showMore: true,
        })
    ]);

    // Results with priority-based sorting
    search.addWidgets([
        instantsearch.widgets.hits({
            container: '#hits',
            templates: {
                item: (hit, { html, components }) => {
                    return html`
                        <div class="search-result-card">
                            <div class="search-result-content">
                                <h2 class="search-result-title">
                                    ${components.Highlight({ attribute: 'title', hit })}
                                </h2>
                                <div class="search-result-meta">
                                    ${hit.category ? html`<span>${hit.category}</span>` : ''}
                                </div>
                                <p class="search-result-excerpt">
                                    ${components.Highlight({ attribute: 'description', hit })}
                                </p>
                            </div>
                        </div>
                    `;
                },
                empty: 'No classifieds found for <q>{{query}}</q>'
            },
            transformItems(items) {
                // Sort by priority (higher priority first)
                return items.sort((a, b) => {
                    const priorityA = a.priority || 0;
                    const priorityB = b.priority || 0;
                    return priorityB - priorityA;
                });
            }
        })
    ]);

    // Pagination
    search.addWidgets([
        instantsearch.widgets.pagination({
            container: '#pagination',
            padding: 2,
        })
    ]);

    search.start();
    }
    
    // Start initialization when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeSearch);
    } else {
        initializeSearch();
    }
})();
</script>
    <?php
    return ob_get_clean();
}

// Register shortcode
add_shortcode( 'cp_classifieds_search', 'cp_shortcode_classifieds_search' );
