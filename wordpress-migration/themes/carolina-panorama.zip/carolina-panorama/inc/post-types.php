<?php
/**
 * Post Types & Taxonomies
 *
 * Registers the 'article' custom post type using the built-in 'category' and
 * 'post_tag' taxonomies so existing WP category/tag infrastructure (widgets,
 * Yoast, Algolia plugin, etc.) works without extra setup.
 *
 * URL structure: /articles/{slug}/
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Register post type ────────────────────────────────────────────────────────

function cp_register_post_types(): void {
    $labels = [
        'name'                  => 'Articles',
        'singular_name'         => 'Article',
        'add_new'               => 'Add New Article',
        'add_new_item'          => 'Add New Article',
        'edit_item'             => 'Edit Article',
        'new_item'              => 'New Article',
        'view_item'             => 'View Article',
        'view_items'            => 'View Articles',
        'search_items'          => 'Search Articles',
        'not_found'             => 'No articles found.',
        'not_found_in_trash'    => 'No articles found in Trash.',
        'parent_item_colon'     => null,
        'all_items'             => 'All Articles',
        'archives'              => 'Article Archives',
        'attributes'            => 'Article Attributes',
        'insert_into_item'      => 'Insert into article',
        'uploaded_to_this_item' => 'Uploaded to this article',
        'featured_image'        => 'Featured Image',
        'set_featured_image'    => 'Set featured image',
        'remove_featured_image' => 'Remove featured image',
        'use_featured_image'    => 'Use as featured image',
        'menu_name'             => 'Articles',
        'filter_items_list'     => 'Filter articles list',
        'items_list_navigation' => 'Articles list navigation',
        'items_list'            => 'Articles list',
        'name_admin_bar'        => 'Article',
    ];

    register_post_type( 'article', [
        'labels'              => $labels,
        'description'         => 'Carolina Panorama newspaper articles.',
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_rest'        => true,   // Required for block editor + REST API
        'query_var'           => true,
        'rewrite'             => [
            'slug'       => 'articles',
            'with_front' => false,
        ],
        'capability_type'     => 'post',
        'has_archive'         => 'articles',  // Enables /articles/ archive page
        'hierarchical'        => false,
        'menu_position'       => 5,           // Below Dashboard, above Media
        'menu_icon'           => 'dashicons-media-text',
        'supports'            => [
            'title',
            'editor',
            'thumbnail',
            'excerpt',
            'author',
            'custom-fields',
            'revisions',
        ],
        // Use WP's built-in taxonomies — no need to register custom ones.
        // This means WP's native Categories / Tags admin UI and all plugins
        // (Yoast, Algolia, etc.) work out of the box.
        'taxonomies'          => [ 'category', 'post_tag' ],
    ] );

    // ── URL rewrite rules ─────────────────────────────────────────────────────
    // Required for Phase 1 (API-driven shortcode pages).
    //
    //  /articles/category/{slug}  ┐
    //  /articles/tag/{slug}       ├─ all serve the 'articles' WP Page;
    //  /articles/author/{slug}    ┘  shortcode JS reads window.location.pathname
    //                                and filters API calls client-side.
    //
    //  /article/{slug} ─────────── serves the 'article' WP Page;
    //                              shortcode reads the slug from the URL path.
    //
    // 'top' priority means these are evaluated before CPT single-post rules,
    // so /articles/category/* is never mistaken for a CPT article slug.
    //
    // Phase 2 note: once content is fully in native WP, delete the 'article'
    // and 'articles' WP Pages so CPT archive/single templates take over, then
    // remove or replace these rules.
    add_rewrite_rule(
        '^articles/(category|tag|author)/([^/]+)/?$',
        'index.php?pagename=articles',
        'top'
    );
    add_rewrite_rule(
        '^article/([^/]+)/?$',
        'index.php?pagename=article',
        'top'
    );
}
add_action( 'init', 'cp_register_post_types' );


// ── Flush rewrite rules on theme activation ───────────────────────────────────
// Without this, /articles/{slug}/ returns 404 until you manually visit
// Settings → Permalinks and hit Save.

function cp_flush_rewrite_rules_on_activation(): void {
    cp_register_post_types();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'cp_flush_rewrite_rules_on_activation' );


// ── Category color codes ──────────────────────────────────────────────────────
// Registers _color_code term meta and adds a color picker to the built-in
// Categories admin screen (Appearance → Categories, or Posts → Categories).

function cp_register_category_color_meta(): void {
    register_term_meta( 'category', '_color_code', [
        'type'              => 'string',
        'description'       => 'Hex color code for this category (e.g. #ff6600)',
        'single'            => true,
        'show_in_rest'      => true,
        'sanitize_callback' => 'sanitize_hex_color',
        'auth_callback'     => function () { return current_user_can( 'manage_categories' ); },
    ] );
}
add_action( 'init', 'cp_register_category_color_meta' );

// Color picker field on the "Add Category" form
add_action( 'category_add_form_fields', function (): void { ?>
    <div class="form-field">
        <label for="cp_color_code"><?php esc_html_e( 'Color', 'carolina-panorama' ); ?></label>
        <input type="color" name="cp_color_code" id="cp_color_code" value="#000000">
        <p class="description">
            <?php esc_html_e( 'Display color for this category (used by article cards and feeds).', 'carolina-panorama' ); ?>
        </p>
    </div>
<?php } );

// Color picker field on the "Edit Category" form (pre-populated)
add_action( 'category_edit_form_fields', function ( WP_Term $term ): void {
    $color = get_term_meta( $term->term_id, '_color_code', true ) ?: '#000000'; ?>
    <tr class="form-field">
        <th scope="row">
            <label for="cp_color_code"><?php esc_html_e( 'Color', 'carolina-panorama' ); ?></label>
        </th>
        <td>
            <input type="color" name="cp_color_code" id="cp_color_code"
                   value="<?php echo esc_attr( $color ); ?>">
            <p class="description">
                <?php esc_html_e( 'Display color for this category (used by article cards and feeds).', 'carolina-panorama' ); ?>
            </p>
        </td>
    </tr>
<?php } );

// Save the field on both add and edit
function cp_save_category_color( int $term_id ): void {
    if ( ! isset( $_POST['cp_color_code'] ) ) {
        return;
    }
    $color = sanitize_hex_color( wp_unslash( $_POST['cp_color_code'] ) );
    if ( $color ) {
        update_term_meta( $term_id, '_color_code', $color );
    }
}
add_action( 'created_category', 'cp_save_category_color' );
add_action( 'edited_category',  'cp_save_category_color' );

// Public helper — use in templates / shortcodes
function cp_get_category_color( int $term_id, string $fallback = '#333333' ): string {
    return get_term_meta( $term_id, '_color_code', true ) ?: $fallback;
}

// ── Featured image fallback ───────────────────────────────────────────────────
// If the importer couldn't download the image (e.g. private S3 bucket), fall
// back to the _featured_image_url postmeta value stored by export_to_wxr.py.

function cp_article_thumbnail_fallback_url( int $post_id ): string {
    if ( has_post_thumbnail( $post_id ) ) {
        return (string) get_the_post_thumbnail_url( $post_id, 'full' );
    }
    return (string) get_post_meta( $post_id, '_featured_image_url', true );
}

function cp_article_thumbnail_fallback_alt( int $post_id ): string {
    if ( has_post_thumbnail( $post_id ) ) {
        return (string) get_post_meta( get_post_thumbnail_id( $post_id ), '_wp_attachment_image_alt', true );
    }
    return (string) get_post_meta( $post_id, '_featured_image_alt', true );
}


// ── Admin: rename "Posts" in the nav menu to "Legacy Posts" ──────────────────
// Prevents confusion between the built-in post type and your new 'article' CPT.

add_action( 'admin_menu', function (): void {
    global $menu, $submenu;

    // Rename top-level "Posts" menu item
    foreach ( $menu as $key => $item ) {
        if ( isset( $item[2] ) && $item[2] === 'edit.php' ) {
            $menu[ $key ][0] = 'Legacy Posts';
            break;
        }
    }

    // Rename "Posts" → "Legacy Posts" in its own submenu
    if ( isset( $submenu['edit.php'] ) ) {
        foreach ( $submenu['edit.php'] as $key => $item ) {
            if ( $item[0] === 'Posts' ) {
                $submenu['edit.php'][ $key ][0] = 'Legacy Posts';
            }
        }
    }
} );
